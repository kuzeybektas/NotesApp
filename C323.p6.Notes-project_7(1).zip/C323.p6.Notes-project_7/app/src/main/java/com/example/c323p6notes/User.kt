package com.example.c323p6notes

//user has an email and password
data class User (
    var email: String = "",
    var password:String = ""
)