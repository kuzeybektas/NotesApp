package com.example.notesapp

//user has an email and password
data class User (
    var email: String = "",
    var password:String = ""
)